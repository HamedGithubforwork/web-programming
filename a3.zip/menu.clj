(ns menu
  (:require [clojure.string :as str] ;; Import clojure.string for string functions
            [clojure.java.io :as io] ;; Import clojure.java.io for file I/O
            [db :as database])) ;; Import the db namespace for database functions



;; Function to display the menu options
(defn showMenu []
  (println "\n\n*** City Information Menu ***")
  (println "-----------------------------\n")
  (println "1. List cities")
  (println "2. Display City Information")
  (println "3. List Provinces")
  (println "4. Display Province Information")
  (println "5. Exit")
  (do
    (print "\nEnter an option? ")
    (flush)
    (str/trim (read-line))))

;; Function to display the cities without details
(defn show-cities [cities]
  (doseq [city cities]
    (print (:city city)" ")))

;; Function to display the cities with details
(defn show-cities-with-details [cities]
  (doseq [city cities]
    (println (:city city) ", Size: " (:size city))))

;; Function to display the cities with density
(defn show-cities-with-density [cities]
  (doseq [city cities]
    (println (:city city) ", Density: " (:density city))))

;; function to display the cities with size and name
(defn option1-2
  [cities-db province-name]
  (println (str "\nListing all cities in " province-name ", ordered by size and name, including population:"))
  (let [cities (database/list-cities-by-province-size cities-db province-name)]
    (doseq [[idx city] (map-indexed vector cities)]
      (println (str (inc idx) ". " (:city city)
                    ", Size: " (:size city)
                    ", Population: " (:population city))))))

;; Functction that displays the menu options and processes the user's choice
(defn option1 [cities-db]
  (println "\n1 List all cities")
  (println "2 List cities by province, ordered by size and name")
  (println "3 List cities by province, ordered by population density")
  (print "Enter an option (1, 2, 3): ")
  (flush)
  (let [sub-option (str/trim (read-line))]
    (cond
      (= sub-option "1")
      (show-cities (database/list-all-cities cities-db))

      ; For options 2 and 3, fetch the province name first, then proceed.
      (or (= sub-option "2") (= sub-option "3"))
      (let [province-name (do (print "Enter the province name: ")
                              (flush)
                              (str/trim (read-line)))]
        (cond
          (= sub-option "2") (option1-2 cities-db province-name) ; Ensure option1-2 accepts province-name
          (= sub-option "3") (show-cities-with-density (database/list-cities-by-province-density cities-db province-name))))

      :else
      (println "Invalid option, please try again."))))


;;function to display city information
(defn option2
  [cities-db] ; Now takes cities-db as a parameter
  (print "\nPlease enter the city name => ")
  (flush)
  (let [city-name (str/trim (read-line))
        city-details (db/find-city cities-db city-name)]  ; Adjust find-city to use cities-db
    (if city-details
      (let [density (db/calculate-density city-details)]
        (println (str "\nDisplaying size, population, land area, population density for " city-name ":"))
        (println (str "Size: " (:size city-details)))
        (println (str "Population: " (:population city-details)))
        (println (str "Land Area: " (:area city-details) " sq km"))
        (println (str "Population Density: " density " per sq km")))
      (println "City not found."))))
;; Function to list provinces and the number of cities in each, sorted by number of cities
(defn option3
  [cities-db]
 ; Lists all provinces with the total number of cities, sorts them, and shows totals.
  (let [province-counts (db/list-provinces cities-db)
        total-provinces (count province-counts)
        total-cities (reduce + (map second province-counts))]
    (println "\nList of provinces and the number of cities in each (ordered by number of cities descending):")
    (doseq [[province count] province-counts]
      (println (str province ": " count " cities")))
    (println (str "\nTotal number of provinces: " total-provinces))
    (println (str "Grand total number of cities: " total-cities))))


;; Function to list provinces with their total populations, ordered by name
(defn option4 [cities-db]
  (println "\nList of provinces with their total populations, ordered by name:")
  (let [provinces-population (database/provinces-total-population cities-db)]
    (doseq [[province population] provinces-population]
      (println province ": " population))))
;; Function to process the user's option and call the appropriate function
(defn processOption
  [option cities-db] ; additional parameters can be specified here if needed
  (cond
    (= option "1") (option1 cities-db)
    (= option "2") (option2 cities-db)
    (= option "3") (option3 cities-db)
    (= option "4") (option4 cities-db) ; Ensure this function is updated to accept cities-db if needed
    :else (println "Invalid Option, please try again")))
;; Function to display the menu and process the user's choice
(defn menu [cities-db] ;; Accept cities-db as an argument
  (loop [] ;; Start an infinite loop
    (let [option (showMenu)] ;; Show the menu and get the user's option
      (if (= option "5") ;; Exit condition
        (println "\nGood Bye\n") ;; Exit message
        (do ;; Process the selected option
          (processOption option cities-db) ;; Pass cities-db to the processing function
          (recur)))))) ;; Recur back to the loop to continue showing the menu

(defn -main [cities-db] ;; Pass cities-db as an argument
  (menu cities-db)) ;; Call menu with cities-db as an argument

