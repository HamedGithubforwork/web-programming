(ns db
  (:require [clojure.string :as str]))

;; Utility function to parse city data from a file
(defn parse-city-data [line]
  (let [[city province size population area] (str/split line #"\|")]
    {:city city
     :province province
     :size size
     :population (read-string population)
     :area (read-string area)}))

;; Loads city data from a file into a data structure
(defn load-data [filename]
  (->> filename
       slurp
       str/split-lines
       (map parse-city-data)))

(def cities-db (load-data "cities.txt"))

;; Lists all cities sorted by name
(defn list-all-cities [cities-db]
  (sort-by :city cities-db))

;; Lists cities filtered by province and sorted by size and then city name
(ns db
  (:require [clojure.string :as str]))

(defn list-cities-by-province-size
  [cities-db province-name]
 ;; Retrieve and sort cities by province, ordered by size and name.
  (->> cities-db
       (filter #(= (:province %) province-name))
       (sort-by (juxt :size :city))))


;; Calculates density for a city and lists cities by density within a province
(defn list-cities-by-province-density [cities-db province-name]
  (->> cities-db
       (filter #(= (:province %) province-name))
       (map #(assoc % :density (/ (:population %) (:area %))))
       (sort-by :density)))

;; Finds a specific city by name, case-insensitively
(defn find-city [cities-db city-name]
  (first (filter #(= (str/lower-case (:city %))
                     (str/lower-case city-name))
                 cities-db)))

;; Calculates population density for a given city
(defn calculate-density [city]
  (let [population (float (:population city))
        area (float (:area city))]
    (/ population area)))

;; Lists provinces and the count of cities within each, sorted by count in descending order
(defn list-provinces [cities-db]
  (->> cities-db
       (map :province)
       frequencies
       (sort-by second >)))

;; Calculates total population for each province
(defn provinces-total-population [cities-db]
  (->> cities-db
       (reduce (fn [acc city]
                 (update acc (:province city) (fnil + 0) (:population city)))
               {})
       (sort-by key)))

