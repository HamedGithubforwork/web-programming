(ns app
  (:require [db :as database]
             [menu :refer [menu]]))

  ;; Require necessary namespaces.
  ;; 'database' alias refers to all the functionality defined in db.clj for database operations.
  ;; 'menu' is imported directly from menu.clj to handle user interactions.
  
(defn -main []
  ;The main entry point of the application.
  ;1. Loads city data from a text file named 'cities.txt'.
  ;2. Initiates the user interaction menu with the loaded data.
  ;; Indicate to the user that the data loading process has started.
  (println "Loading city data...")

  ;; Load the city data using the `load-data` function from the `database` namespace.
  ;; This function is expected to return a data structure with all city information loaded from 'cities.txt'.
  (let [cities-db (database/load-data "cities.txt")]

    ;; Inform the user that the data has been loaded successfully.
    (println "Data loaded successfully.")

    ;; Call the `menu` function, passing it the loaded city data.
    ;; This function handles all subsequent user interactions based on the loaded data.
    (menu cities-db)))

;; Call `-main` to start the application automatically when this script is run.
(-main)
